# aqui sera la interfaz principal que ejecutara por boton en pantalla alguna de las 2 a 3 interfaces que se utilizaran 
from .Code import control_dash
from .Context import register_dash
from .Database import read_MCU
from .Animation import animation_dash