from tkinter import *
import tkinter as tk
import datetime as dt

from foder_body import zone_date as zdate
from foder_body import zone_datainfo as zinfo
    
def the_body(window):
    # -------------------------------- Titulos de variables de tiempo a consultar
    zdate.body_textzone_date(window)
    # -------------------------------- Zona informacion (prueba)
    #zinfo.dataset_info()

