# 📦 Dashboard (`version 2`)

This is a dashboard app created in Python using Streamlit.

## Demo App

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://dash-board.streamlitapp.com/)

## YouTube Tutorial

<a href="https://youtu.be/o6wQ8zAkLxc"><img src="https://img.youtube.com/vi/o6wQ8zAkLxc/maxresdefault.jpg" alt="Building a Dashboard web app in Python - Full Streamlit Tutorial" title="Building a Dashboard web app in Python - Full Streamlit Tutorial" width="450"/></a>
